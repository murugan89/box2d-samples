#ifndef _COMMON_H_INCLUDED
#define _COMMON_H_INCLUDED

#include <stdlib.h>
#include <stdio.h>
#include <stdexcept>
#include <math.h>

#ifdef WIN32
#include <EGL/egl.h>
#endif

#include <GLES2/gl2.h>

#endif //_COMMON_H_