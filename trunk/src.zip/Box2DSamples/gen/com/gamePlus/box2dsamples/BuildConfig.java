/** Automatically generated file. DO NOT MODIFY */
package com.gamePlus.box2dsamples;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}